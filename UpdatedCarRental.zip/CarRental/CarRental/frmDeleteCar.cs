﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRental
{
    public partial class frmDeleteCar : Form
    {
        private DatabaseOperations dbOperations = new DatabaseOperations();
        private BindingSource carBindingSource = new BindingSource();
        public frmDeleteCar()
        {
            InitializeComponent();
        }
        private void LoadCarData()
        {
            DataTable carsTable = dbOperations.GetAllCars();
            carBindingSource.DataSource = carsTable;
            dgvDeleteCarView.DataSource = carBindingSource;
        }
        private void btnDeleteCar_Click(object sender, EventArgs e)
        {
            if (dgvDeleteCarView.SelectedRows.Count > 0)
            {
                int selectedCarId = (int)dgvDeleteCarView.SelectedRows[0].Cells["CarID"].Value;

                var confirmResult = MessageBox.Show("Are you sure you want to delete this car?",
                                                    "Confirm Delete",
                                                    MessageBoxButtons.YesNo);
                if (confirmResult == DialogResult.Yes)
                {
                    DatabaseOperations dbOperations = new DatabaseOperations();
                    bool isDeleted = dbOperations.DeleteCar(selectedCarId);

                    if (isDeleted)
                    {
                        MessageBox.Show("Car deleted successfully.");
                        LoadCarData(); 
                    }
                    else
                    {
                        MessageBox.Show("Failed to delete car.");
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a car to delete.");
            }
        }
        private void frmDeleteCar_Load(object sender, EventArgs e)
        {
            LoadCarData();

        }
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string selectedCategory = cbCategoryFilter.SelectedItem?.ToString();
            bool? isAvailable = chkAvailableFilter.Checked;
            DataTable searchResults = dbOperations.SearchCars(selectedCategory, isAvailable);
            carBindingSource.DataSource = searchResults;
        }
    }
}
