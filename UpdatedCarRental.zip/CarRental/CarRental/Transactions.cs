﻿using CarRental.CarRental;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRental
{
    internal class Transactions
    {
        private int transactionID;
        private DateTime rentalDate;
        private Customer customer;
        private Car car;
        private int daysRented;

        public int TransactionID { get { return transactionID; } private set { transactionID = value; } }
        public DateTime RentalDate { get { return rentalDate; } set { rentalDate = value; } }
        public Customer Customer { get { return customer; } set { customer = value; } }
        public Car Car { get { return car; } set { car = value; } }
        public int DaysRented { get { return daysRented; } set { daysRented = value; } }
        public Transactions(DateTime rentalDate, Customer customer, Car car, int daysRented)
        {
            RentalDate = rentalDate;
            Customer = customer;
            Car = car;
            DaysRented = daysRented;
        }
        public static decimal CalculateTotalCost(Car car, decimal daysRented)
        {
            decimal totalCost = car.RentalCostPerDay * daysRented;
            decimal carTax = totalCost * (decimal)0.08;
            totalCost = totalCost + carTax;
            return totalCost;
        }
        public static decimal CalculateTax(Car car, decimal daysRented)
        {
            decimal totalCost = car.RentalCostPerDay * daysRented;
            decimal carTax = totalCost * (decimal)0.08;
            return carTax; 
        }

    }
}
