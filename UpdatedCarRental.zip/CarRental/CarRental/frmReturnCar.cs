﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRental
{
    public partial class frmReturnCar : Form
    {
        private CarInventory inventory;
        internal frmReturnCar()
        {
            InitializeComponent();
            inventory = new CarInventory();
        }
        private void frmReturnCar_Load(object sender, EventArgs e)
        {
            var rentedCars = inventory.GetCars().Where(car => !car.IsAvailable).ToList();
            cbRentedCars.DataSource = rentedCars;
            cbRentedCars.DisplayMember = "Model";
        }
        private void btnConfirmReturn_Click(object sender, EventArgs e)
        {
            if (cbRentedCars.SelectedItem is Car selectedCar)
            {
                selectedCar.IsAvailable = true;
                selectedCar.Mileage = int.Parse(txtNewMileage.Text);
                selectedCar.Damages = txtDamage.Text;
                bool isUpdated = inventory.UpdateCar(selectedCar.CarID, selectedCar);
                if (isUpdated)
                {
                    MessageBox.Show("The car has been successfully returned and is now available for rent.");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Failed to update car information in the database.");
                }
            }
        }
    }
}