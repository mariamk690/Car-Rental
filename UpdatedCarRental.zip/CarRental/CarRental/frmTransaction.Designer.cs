﻿namespace CarRental
{
    partial class frmTransaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbCustInfo = new System.Windows.Forms.GroupBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtPhoneNumber = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.gbLicenseInfo = new System.Windows.Forms.GroupBox();
            this.txtLicenseState = new System.Windows.Forms.TextBox();
            this.txtLicenseNumber = new System.Windows.Forms.TextBox();
            this.gbInsuranceInfo = new System.Windows.Forms.GroupBox();
            this.txtPolicyNumber = new System.Windows.Forms.TextBox();
            this.txtPolicyHolder = new System.Windows.Forms.TextBox();
            this.lblHMDays = new System.Windows.Forms.Label();
            this.txtDays = new System.Windows.Forms.TextBox();
            this.lblReceipt = new System.Windows.Forms.Label();
            this.lblCarInfo = new System.Windows.Forms.Label();
            this.btnConfirmCarRental = new System.Windows.Forms.Button();
            this.btnAddCustomer = new System.Windows.Forms.Button();
            this.gbCustInfo.SuspendLayout();
            this.gbLicenseInfo.SuspendLayout();
            this.gbInsuranceInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbCustInfo
            // 
            this.gbCustInfo.Controls.Add(this.txtAddress);
            this.gbCustInfo.Controls.Add(this.txtPhoneNumber);
            this.gbCustInfo.Controls.Add(this.txtName);
            this.gbCustInfo.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbCustInfo.Location = new System.Drawing.Point(21, 20);
            this.gbCustInfo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbCustInfo.Name = "gbCustInfo";
            this.gbCustInfo.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbCustInfo.Size = new System.Drawing.Size(201, 140);
            this.gbCustInfo.TabIndex = 0;
            this.gbCustInfo.TabStop = false;
            this.gbCustInfo.Text = "Customer Information";
            // 
            // txtAddress
            // 
            this.txtAddress.Font = new System.Drawing.Font("Microsoft YaHei Light", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(19, 86);
            this.txtAddress.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(100, 25);
            this.txtAddress.TabIndex = 2;
            this.txtAddress.Text = "Address";
            // 
            // txtPhoneNumber
            // 
            this.txtPhoneNumber.Font = new System.Drawing.Font("Microsoft YaHei Light", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhoneNumber.Location = new System.Drawing.Point(19, 55);
            this.txtPhoneNumber.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPhoneNumber.Name = "txtPhoneNumber";
            this.txtPhoneNumber.Size = new System.Drawing.Size(100, 25);
            this.txtPhoneNumber.TabIndex = 1;
            this.txtPhoneNumber.Text = "Phone Number";
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Microsoft YaHei Light", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(19, 25);
            this.txtName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 25);
            this.txtName.TabIndex = 0;
            this.txtName.Text = "Name";
            // 
            // gbLicenseInfo
            // 
            this.gbLicenseInfo.Controls.Add(this.txtLicenseState);
            this.gbLicenseInfo.Controls.Add(this.txtLicenseNumber);
            this.gbLicenseInfo.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbLicenseInfo.Location = new System.Drawing.Point(21, 178);
            this.gbLicenseInfo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbLicenseInfo.Name = "gbLicenseInfo";
            this.gbLicenseInfo.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbLicenseInfo.Size = new System.Drawing.Size(181, 98);
            this.gbLicenseInfo.TabIndex = 1;
            this.gbLicenseInfo.TabStop = false;
            this.gbLicenseInfo.Text = "Driver\'s License";
            // 
            // txtLicenseState
            // 
            this.txtLicenseState.Font = new System.Drawing.Font("Microsoft YaHei Light", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLicenseState.Location = new System.Drawing.Point(19, 55);
            this.txtLicenseState.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtLicenseState.Name = "txtLicenseState";
            this.txtLicenseState.Size = new System.Drawing.Size(100, 25);
            this.txtLicenseState.TabIndex = 2;
            this.txtLicenseState.Text = "DL State";
            // 
            // txtLicenseNumber
            // 
            this.txtLicenseNumber.Font = new System.Drawing.Font("Microsoft YaHei Light", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLicenseNumber.Location = new System.Drawing.Point(19, 25);
            this.txtLicenseNumber.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtLicenseNumber.Name = "txtLicenseNumber";
            this.txtLicenseNumber.Size = new System.Drawing.Size(100, 25);
            this.txtLicenseNumber.TabIndex = 1;
            this.txtLicenseNumber.Text = "DL Number";
            // 
            // gbInsuranceInfo
            // 
            this.gbInsuranceInfo.Controls.Add(this.txtPolicyNumber);
            this.gbInsuranceInfo.Controls.Add(this.txtPolicyHolder);
            this.gbInsuranceInfo.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbInsuranceInfo.Location = new System.Drawing.Point(21, 304);
            this.gbInsuranceInfo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbInsuranceInfo.Name = "gbInsuranceInfo";
            this.gbInsuranceInfo.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbInsuranceInfo.Size = new System.Drawing.Size(201, 98);
            this.gbInsuranceInfo.TabIndex = 2;
            this.gbInsuranceInfo.TabStop = false;
            this.gbInsuranceInfo.Text = "Insurance Information";
            // 
            // txtPolicyNumber
            // 
            this.txtPolicyNumber.Font = new System.Drawing.Font("Microsoft YaHei Light", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPolicyNumber.Location = new System.Drawing.Point(19, 55);
            this.txtPolicyNumber.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPolicyNumber.Name = "txtPolicyNumber";
            this.txtPolicyNumber.Size = new System.Drawing.Size(100, 25);
            this.txtPolicyNumber.TabIndex = 2;
            this.txtPolicyNumber.Text = "Policy Number";
            // 
            // txtPolicyHolder
            // 
            this.txtPolicyHolder.Font = new System.Drawing.Font("Microsoft YaHei Light", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPolicyHolder.Location = new System.Drawing.Point(19, 25);
            this.txtPolicyHolder.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPolicyHolder.Name = "txtPolicyHolder";
            this.txtPolicyHolder.Size = new System.Drawing.Size(100, 25);
            this.txtPolicyHolder.TabIndex = 1;
            this.txtPolicyHolder.Text = "Policy Holder";
            // 
            // lblHMDays
            // 
            this.lblHMDays.AutoSize = true;
            this.lblHMDays.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHMDays.Location = new System.Drawing.Point(36, 406);
            this.lblHMDays.Name = "lblHMDays";
            this.lblHMDays.Size = new System.Drawing.Size(120, 19);
            this.lblHMDays.TabIndex = 3;
            this.lblHMDays.Text = "How many days?";
            // 
            // txtDays
            // 
            this.txtDays.Location = new System.Drawing.Point(56, 428);
            this.txtDays.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDays.Name = "txtDays";
            this.txtDays.Size = new System.Drawing.Size(68, 22);
            this.txtDays.TabIndex = 4;
            // 
            // lblReceipt
            // 
            this.lblReceipt.AutoSize = true;
            this.lblReceipt.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReceipt.Location = new System.Drawing.Point(245, 154);
            this.lblReceipt.Name = "lblReceipt";
            this.lblReceipt.Size = new System.Drawing.Size(177, 19);
            this.lblReceipt.TabIndex = 5;
            this.lblReceipt.Text = "Receipt will Appear Here";
            // 
            // lblCarInfo
            // 
            this.lblCarInfo.AutoSize = true;
            this.lblCarInfo.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarInfo.Location = new System.Drawing.Point(245, 32);
            this.lblCarInfo.Name = "lblCarInfo";
            this.lblCarInfo.Size = new System.Drawing.Size(212, 19);
            this.lblCarInfo.TabIndex = 6;
            this.lblCarInfo.Text = "Car Information Appears Here";
            // 
            // btnConfirmCarRental
            // 
            this.btnConfirmCarRental.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirmCarRental.Location = new System.Drawing.Point(245, 354);
            this.btnConfirmCarRental.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnConfirmCarRental.Name = "btnConfirmCarRental";
            this.btnConfirmCarRental.Size = new System.Drawing.Size(188, 47);
            this.btnConfirmCarRental.TabIndex = 7;
            this.btnConfirmCarRental.Text = "Confirm Car Rental";
            this.btnConfirmCarRental.UseVisualStyleBackColor = true;
            this.btnConfirmCarRental.Click += new System.EventHandler(this.btnConfirmCarRental_Click);
            // 
            // btnAddCustomer
            // 
            this.btnAddCustomer.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCustomer.Location = new System.Drawing.Point(245, 303);
            this.btnAddCustomer.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAddCustomer.Name = "btnAddCustomer";
            this.btnAddCustomer.Size = new System.Drawing.Size(188, 47);
            this.btnAddCustomer.TabIndex = 8;
            this.btnAddCustomer.Text = "Add Customer";
            this.btnAddCustomer.UseVisualStyleBackColor = true;
            this.btnAddCustomer.Click += new System.EventHandler(this.btnAddCustomer_Click);
            // 
            // frmTransaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(503, 481);
            this.Controls.Add(this.btnAddCustomer);
            this.Controls.Add(this.btnConfirmCarRental);
            this.Controls.Add(this.lblCarInfo);
            this.Controls.Add(this.lblReceipt);
            this.Controls.Add(this.txtDays);
            this.Controls.Add(this.lblHMDays);
            this.Controls.Add(this.gbInsuranceInfo);
            this.Controls.Add(this.gbLicenseInfo);
            this.Controls.Add(this.gbCustInfo);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmTransaction";
            this.Text = "Transaction";
            this.Load += new System.EventHandler(this.frmTransaction_Load);
            this.gbCustInfo.ResumeLayout(false);
            this.gbCustInfo.PerformLayout();
            this.gbLicenseInfo.ResumeLayout(false);
            this.gbLicenseInfo.PerformLayout();
            this.gbInsuranceInfo.ResumeLayout(false);
            this.gbInsuranceInfo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbCustInfo;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtPhoneNumber;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.GroupBox gbLicenseInfo;
        private System.Windows.Forms.TextBox txtLicenseState;
        private System.Windows.Forms.TextBox txtLicenseNumber;
        private System.Windows.Forms.GroupBox gbInsuranceInfo;
        private System.Windows.Forms.TextBox txtPolicyNumber;
        private System.Windows.Forms.TextBox txtPolicyHolder;
        private System.Windows.Forms.Label lblHMDays;
        private System.Windows.Forms.TextBox txtDays;
        private System.Windows.Forms.Label lblReceipt;
        private System.Windows.Forms.Label lblCarInfo;
        private System.Windows.Forms.Button btnConfirmCarRental;
        private System.Windows.Forms.Button btnAddCustomer;
    }
}