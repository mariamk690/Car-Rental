﻿namespace CarRental
{
    partial class frmAddCars
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbCarInfo = new System.Windows.Forms.GroupBox();
            this.txtDamages = new System.Windows.Forms.TextBox();
            this.btnStoreCar = new System.Windows.Forms.Button();
            this.txtImageURL = new System.Windows.Forms.TextBox();
            this.txtParkingSpot = new System.Windows.Forms.TextBox();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.txtMileage = new System.Windows.Forms.TextBox();
            this.chkIsAvailable = new System.Windows.Forms.CheckBox();
            this.txtRentCostPerDay = new System.Windows.Forms.TextBox();
            this.txtYear = new System.Windows.Forms.TextBox();
            this.txtModel = new System.Windows.Forms.TextBox();
            this.txtManufacturer = new System.Windows.Forms.TextBox();
            this.cbCategory = new System.Windows.Forms.ComboBox();
            this.pbCarImage = new System.Windows.Forms.PictureBox();
            this.btnSwitchToRentForm = new System.Windows.Forms.Button();
            this.btnClearForm = new System.Windows.Forms.Button();
            this.btnSwitchToDeleteForm = new System.Windows.Forms.Button();
            this.btnSwitchToUpdateForm = new System.Windows.Forms.Button();
            this.gbCarInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCarImage)).BeginInit();
            this.SuspendLayout();
            // 
            // gbCarInfo
            // 
            this.gbCarInfo.Controls.Add(this.txtDamages);
            this.gbCarInfo.Controls.Add(this.btnStoreCar);
            this.gbCarInfo.Controls.Add(this.txtImageURL);
            this.gbCarInfo.Controls.Add(this.txtParkingSpot);
            this.gbCarInfo.Controls.Add(this.txtDescription);
            this.gbCarInfo.Controls.Add(this.txtMileage);
            this.gbCarInfo.Controls.Add(this.chkIsAvailable);
            this.gbCarInfo.Controls.Add(this.txtRentCostPerDay);
            this.gbCarInfo.Controls.Add(this.txtYear);
            this.gbCarInfo.Controls.Add(this.txtModel);
            this.gbCarInfo.Controls.Add(this.txtManufacturer);
            this.gbCarInfo.Controls.Add(this.cbCategory);
            this.gbCarInfo.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbCarInfo.Location = new System.Drawing.Point(20, 18);
            this.gbCarInfo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbCarInfo.Name = "gbCarInfo";
            this.gbCarInfo.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbCarInfo.Size = new System.Drawing.Size(245, 397);
            this.gbCarInfo.TabIndex = 0;
            this.gbCarInfo.TabStop = false;
            this.gbCarInfo.Text = "Car Information";
            // 
            // txtDamages
            // 
            this.txtDamages.Font = new System.Drawing.Font("Microsoft YaHei Light", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDamages.Location = new System.Drawing.Point(61, 328);
            this.txtDamages.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDamages.Name = "txtDamages";
            this.txtDamages.Size = new System.Drawing.Size(120, 25);
            this.txtDamages.TabIndex = 10;
            this.txtDamages.Text = "Damages?";
            // 
            // btnStoreCar
            // 
            this.btnStoreCar.Location = new System.Drawing.Point(72, 357);
            this.btnStoreCar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnStoreCar.Name = "btnStoreCar";
            this.btnStoreCar.Size = new System.Drawing.Size(97, 34);
            this.btnStoreCar.TabIndex = 11;
            this.btnStoreCar.Text = "Store Car";
            this.btnStoreCar.UseVisualStyleBackColor = true;
            this.btnStoreCar.Click += new System.EventHandler(this.btnStoreCar_Click);
            // 
            // txtImageURL
            // 
            this.txtImageURL.Font = new System.Drawing.Font("Microsoft YaHei Light", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtImageURL.Location = new System.Drawing.Point(26, 299);
            this.txtImageURL.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtImageURL.Name = "txtImageURL";
            this.txtImageURL.Size = new System.Drawing.Size(177, 25);
            this.txtImageURL.TabIndex = 9;
            this.txtImageURL.Text = "Enter car image URL";
            this.txtImageURL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtParkingSpot
            // 
            this.txtParkingSpot.Font = new System.Drawing.Font("Microsoft YaHei Light", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtParkingSpot.Location = new System.Drawing.Point(61, 270);
            this.txtParkingSpot.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtParkingSpot.Name = "txtParkingSpot";
            this.txtParkingSpot.Size = new System.Drawing.Size(120, 25);
            this.txtParkingSpot.TabIndex = 8;
            this.txtParkingSpot.Text = "Parking Spot";
            // 
            // txtDescription
            // 
            this.txtDescription.Font = new System.Drawing.Font("Microsoft YaHei Light", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescription.Location = new System.Drawing.Point(61, 241);
            this.txtDescription.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(120, 22);
            this.txtDescription.TabIndex = 7;
            this.txtDescription.Text = "Description";
            // 
            // txtMileage
            // 
            this.txtMileage.Font = new System.Drawing.Font("Microsoft YaHei Light", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMileage.Location = new System.Drawing.Point(61, 150);
            this.txtMileage.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMileage.Name = "txtMileage";
            this.txtMileage.Size = new System.Drawing.Size(120, 25);
            this.txtMileage.TabIndex = 4;
            this.txtMileage.Text = "Mileage";
            // 
            // chkIsAvailable
            // 
            this.chkIsAvailable.AutoSize = true;
            this.chkIsAvailable.Location = new System.Drawing.Point(72, 181);
            this.chkIsAvailable.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chkIsAvailable.Name = "chkIsAvailable";
            this.chkIsAvailable.Size = new System.Drawing.Size(100, 23);
            this.chkIsAvailable.TabIndex = 5;
            this.chkIsAvailable.Text = "Available?";
            this.chkIsAvailable.UseVisualStyleBackColor = true;
            // 
            // txtRentCostPerDay
            // 
            this.txtRentCostPerDay.Font = new System.Drawing.Font("Microsoft YaHei Light", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRentCostPerDay.Location = new System.Drawing.Point(61, 210);
            this.txtRentCostPerDay.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtRentCostPerDay.Name = "txtRentCostPerDay";
            this.txtRentCostPerDay.Size = new System.Drawing.Size(121, 25);
            this.txtRentCostPerDay.TabIndex = 6;
            this.txtRentCostPerDay.Text = "Rental Cost/Day";
            // 
            // txtYear
            // 
            this.txtYear.Font = new System.Drawing.Font("Microsoft YaHei Light", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtYear.Location = new System.Drawing.Point(61, 119);
            this.txtYear.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtYear.Name = "txtYear";
            this.txtYear.Size = new System.Drawing.Size(120, 25);
            this.txtYear.TabIndex = 3;
            this.txtYear.Text = "Year";
            // 
            // txtModel
            // 
            this.txtModel.Font = new System.Drawing.Font("Microsoft YaHei Light", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtModel.Location = new System.Drawing.Point(61, 89);
            this.txtModel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtModel.Name = "txtModel";
            this.txtModel.Size = new System.Drawing.Size(120, 25);
            this.txtModel.TabIndex = 2;
            this.txtModel.Text = "Model";
            // 
            // txtManufacturer
            // 
            this.txtManufacturer.Font = new System.Drawing.Font("Microsoft YaHei Light", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtManufacturer.Location = new System.Drawing.Point(63, 57);
            this.txtManufacturer.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtManufacturer.Name = "txtManufacturer";
            this.txtManufacturer.Size = new System.Drawing.Size(120, 25);
            this.txtManufacturer.TabIndex = 1;
            this.txtManufacturer.Text = "Manufacturer";
            // 
            // cbCategory
            // 
            this.cbCategory.Font = new System.Drawing.Font("Microsoft YaHei Light", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbCategory.FormattingEnabled = true;
            this.cbCategory.Items.AddRange(new object[] {
            "Economy",
            "Luxury",
            "Sedan",
            "SUV",
            "Pickup Truck",
            "Limo",
            "Van"});
            this.cbCategory.Location = new System.Drawing.Point(61, 25);
            this.cbCategory.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbCategory.Name = "cbCategory";
            this.cbCategory.Size = new System.Drawing.Size(121, 27);
            this.cbCategory.TabIndex = 0;
            this.cbCategory.Text = "Select Category";
            // 
            // pbCarImage
            // 
            this.pbCarImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbCarImage.Location = new System.Drawing.Point(308, 26);
            this.pbCarImage.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbCarImage.Name = "pbCarImage";
            this.pbCarImage.Size = new System.Drawing.Size(517, 342);
            this.pbCarImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCarImage.TabIndex = 1;
            this.pbCarImage.TabStop = false;
            // 
            // btnSwitchToRentForm
            // 
            this.btnSwitchToRentForm.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSwitchToRentForm.Location = new System.Drawing.Point(461, 372);
            this.btnSwitchToRentForm.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSwitchToRentForm.Name = "btnSwitchToRentForm";
            this.btnSwitchToRentForm.Size = new System.Drawing.Size(219, 28);
            this.btnSwitchToRentForm.TabIndex = 2;
            this.btnSwitchToRentForm.Text = "View All Cars in Inventory";
            this.btnSwitchToRentForm.UseVisualStyleBackColor = true;
            this.btnSwitchToRentForm.Click += new System.EventHandler(this.btnSwitchToRentForm_Click);
            // 
            // btnClearForm
            // 
            this.btnClearForm.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearForm.Location = new System.Drawing.Point(69, 434);
            this.btnClearForm.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnClearForm.Name = "btnClearForm";
            this.btnClearForm.Size = new System.Drawing.Size(144, 30);
            this.btnClearForm.TabIndex = 3;
            this.btnClearForm.Text = "Clear Form";
            this.btnClearForm.UseVisualStyleBackColor = true;
            this.btnClearForm.Click += new System.EventHandler(this.btnClearForm_Click);
            // 
            // btnSwitchToDeleteForm
            // 
            this.btnSwitchToDeleteForm.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSwitchToDeleteForm.Location = new System.Drawing.Point(461, 404);
            this.btnSwitchToDeleteForm.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSwitchToDeleteForm.Name = "btnSwitchToDeleteForm";
            this.btnSwitchToDeleteForm.Size = new System.Drawing.Size(219, 28);
            this.btnSwitchToDeleteForm.TabIndex = 4;
            this.btnSwitchToDeleteForm.Text = "Delete Car from DB";
            this.btnSwitchToDeleteForm.UseVisualStyleBackColor = true;
            this.btnSwitchToDeleteForm.Click += new System.EventHandler(this.btnSwitchToDeleteForm_Click);
            // 
            // btnSwitchToUpdateForm
            // 
            this.btnSwitchToUpdateForm.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSwitchToUpdateForm.Location = new System.Drawing.Point(461, 434);
            this.btnSwitchToUpdateForm.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSwitchToUpdateForm.Name = "btnSwitchToUpdateForm";
            this.btnSwitchToUpdateForm.Size = new System.Drawing.Size(219, 28);
            this.btnSwitchToUpdateForm.TabIndex = 5;
            this.btnSwitchToUpdateForm.Text = "Update Cars in DB";
            this.btnSwitchToUpdateForm.UseVisualStyleBackColor = true;
            this.btnSwitchToUpdateForm.Click += new System.EventHandler(this.btnSwitchToUpdateForm_Click);
            // 
            // frmAddCars
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(837, 492);
            this.Controls.Add(this.btnSwitchToUpdateForm);
            this.Controls.Add(this.btnSwitchToDeleteForm);
            this.Controls.Add(this.btnClearForm);
            this.Controls.Add(this.btnSwitchToRentForm);
            this.Controls.Add(this.pbCarImage);
            this.Controls.Add(this.gbCarInfo);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmAddCars";
            this.Text = "Add Cars";
            this.Load += new System.EventHandler(this.frmAddCars_Load);
            this.gbCarInfo.ResumeLayout(false);
            this.gbCarInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCarImage)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbCarInfo;
        private System.Windows.Forms.ComboBox cbCategory;
        private System.Windows.Forms.CheckBox chkIsAvailable;
        private System.Windows.Forms.TextBox txtRentCostPerDay;
        private System.Windows.Forms.TextBox txtYear;
        private System.Windows.Forms.TextBox txtModel;
        private System.Windows.Forms.TextBox txtManufacturer;
        private System.Windows.Forms.TextBox txtMileage;
        private System.Windows.Forms.TextBox txtImageURL;
        private System.Windows.Forms.TextBox txtParkingSpot;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.PictureBox pbCarImage;
        private System.Windows.Forms.Button btnStoreCar;
        private System.Windows.Forms.Button btnSwitchToRentForm;
        private System.Windows.Forms.Button btnClearForm;
        private System.Windows.Forms.TextBox txtDamages;
        private System.Windows.Forms.Button btnSwitchToDeleteForm;
        private System.Windows.Forms.Button btnSwitchToUpdateForm;
    }
}

