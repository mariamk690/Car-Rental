﻿namespace CarRental
{
    partial class frmRentCarView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbSearchFilters = new System.Windows.Forms.GroupBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.chkAvailableFilter = new System.Windows.Forms.CheckBox();
            this.cbCategoryFilter = new System.Windows.Forms.ComboBox();
            this.pbDetailedCarView = new System.Windows.Forms.PictureBox();
            this.btnConfirmCar = new System.Windows.Forms.Button();
            this.btnSwitchToReturnForm = new System.Windows.Forms.Button();
            this.lblDetailedCarInfo = new System.Windows.Forms.Label();
            this.dgvCarView = new System.Windows.Forms.DataGridView();
            this.gbSearchFilters.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDetailedCarView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCarView)).BeginInit();
            this.SuspendLayout();
            // 
            // gbSearchFilters
            // 
            this.gbSearchFilters.Controls.Add(this.btnSearch);
            this.gbSearchFilters.Controls.Add(this.chkAvailableFilter);
            this.gbSearchFilters.Controls.Add(this.cbCategoryFilter);
            this.gbSearchFilters.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSearchFilters.Location = new System.Drawing.Point(15, 30);
            this.gbSearchFilters.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbSearchFilters.Name = "gbSearchFilters";
            this.gbSearchFilters.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbSearchFilters.Size = new System.Drawing.Size(139, 148);
            this.gbSearchFilters.TabIndex = 1;
            this.gbSearchFilters.TabStop = false;
            this.gbSearchFilters.Text = "Search Filters";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(25, 104);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(87, 30);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // chkAvailableFilter
            // 
            this.chkAvailableFilter.AutoSize = true;
            this.chkAvailableFilter.Location = new System.Drawing.Point(19, 77);
            this.chkAvailableFilter.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chkAvailableFilter.Name = "chkAvailableFilter";
            this.chkAvailableFilter.Size = new System.Drawing.Size(100, 23);
            this.chkAvailableFilter.TabIndex = 1;
            this.chkAvailableFilter.Text = "Available?";
            this.chkAvailableFilter.UseVisualStyleBackColor = true;
            // 
            // cbCategoryFilter
            // 
            this.cbCategoryFilter.Font = new System.Drawing.Font("Microsoft YaHei Light", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbCategoryFilter.FormattingEnabled = true;
            this.cbCategoryFilter.Items.AddRange(new object[] {
            "Economy",
            "Luxury",
            "Sedan",
            "SUV",
            "Pickup Truck",
            "Limo",
            "Van"});
            this.cbCategoryFilter.Location = new System.Drawing.Point(19, 33);
            this.cbCategoryFilter.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbCategoryFilter.Name = "cbCategoryFilter";
            this.cbCategoryFilter.Size = new System.Drawing.Size(93, 27);
            this.cbCategoryFilter.TabIndex = 0;
            this.cbCategoryFilter.Text = "Category";
            // 
            // pbDetailedCarView
            // 
            this.pbDetailedCarView.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbDetailedCarView.Location = new System.Drawing.Point(926, 14);
            this.pbDetailedCarView.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbDetailedCarView.Name = "pbDetailedCarView";
            this.pbDetailedCarView.Size = new System.Drawing.Size(533, 315);
            this.pbDetailedCarView.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbDetailedCarView.TabIndex = 3;
            this.pbDetailedCarView.TabStop = false;
            // 
            // btnConfirmCar
            // 
            this.btnConfirmCar.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirmCar.Location = new System.Drawing.Point(1051, 333);
            this.btnConfirmCar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnConfirmCar.Name = "btnConfirmCar";
            this.btnConfirmCar.Size = new System.Drawing.Size(291, 60);
            this.btnConfirmCar.TabIndex = 4;
            this.btnConfirmCar.Text = "Confirm Car Selection";
            this.btnConfirmCar.UseVisualStyleBackColor = true;
            this.btnConfirmCar.Click += new System.EventHandler(this.btnConfirmCar_Click);
            // 
            // btnSwitchToReturnForm
            // 
            this.btnSwitchToReturnForm.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSwitchToReturnForm.Location = new System.Drawing.Point(20, 213);
            this.btnSwitchToReturnForm.Name = "btnSwitchToReturnForm";
            this.btnSwitchToReturnForm.Size = new System.Drawing.Size(110, 83);
            this.btnSwitchToReturnForm.TabIndex = 5;
            this.btnSwitchToReturnForm.Text = "Click here to return a car!";
            this.btnSwitchToReturnForm.UseVisualStyleBackColor = true;
            this.btnSwitchToReturnForm.Click += new System.EventHandler(this.btnSwitchToReturnForm_Click);
            // 
            // lblDetailedCarInfo
            // 
            this.lblDetailedCarInfo.AutoSize = true;
            this.lblDetailedCarInfo.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDetailedCarInfo.Location = new System.Drawing.Point(156, 333);
            this.lblDetailedCarInfo.Name = "lblDetailedCarInfo";
            this.lblDetailedCarInfo.Size = new System.Drawing.Size(296, 19);
            this.lblDetailedCarInfo.TabIndex = 6;
            this.lblDetailedCarInfo.Text = "Detailed Car Information Will Appear Here";
            // 
            // dgvCarView
            // 
            this.dgvCarView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCarView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvCarView.Location = new System.Drawing.Point(160, 12);
            this.dgvCarView.MultiSelect = false;
            this.dgvCarView.Name = "dgvCarView";
            this.dgvCarView.RowHeadersWidth = 51;
            this.dgvCarView.RowTemplate.Height = 24;
            this.dgvCarView.Size = new System.Drawing.Size(737, 317);
            this.dgvCarView.TabIndex = 7;
            this.dgvCarView.SelectionChanged += new System.EventHandler(this.dgvCarView_SelectionChanged);
            // 
            // frmRentCarView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1471, 450);
            this.Controls.Add(this.dgvCarView);
            this.Controls.Add(this.lblDetailedCarInfo);
            this.Controls.Add(this.btnSwitchToReturnForm);
            this.Controls.Add(this.btnConfirmCar);
            this.Controls.Add(this.pbDetailedCarView);
            this.Controls.Add(this.gbSearchFilters);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmRentCarView";
            this.Text = "Car View";
            this.Load += new System.EventHandler(this.frmRentCarView_Load);
            this.gbSearchFilters.ResumeLayout(false);
            this.gbSearchFilters.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDetailedCarView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCarView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox gbSearchFilters;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.CheckBox chkAvailableFilter;
        private System.Windows.Forms.ComboBox cbCategoryFilter;
        private System.Windows.Forms.PictureBox pbDetailedCarView;
        private System.Windows.Forms.Button btnConfirmCar;
        private System.Windows.Forms.Button btnSwitchToReturnForm;
        private System.Windows.Forms.Label lblDetailedCarInfo;
        private System.Windows.Forms.DataGridView dgvCarView;
    }
}