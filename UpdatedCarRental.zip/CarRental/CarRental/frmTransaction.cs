﻿using CarRental.CarRental;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRental
{
    public partial class frmTransaction : Form
    {
        private Customer currentCustomer;
        private string detailedCarInfo;
        private Car currentCar;
        private CarInventory currentInventory;
        internal frmTransaction(Car selectedCar, string detailedInfo, CarInventory inventory)
        {
            InitializeComponent();
            detailedCarInfo = detailedInfo;
            currentCar = selectedCar;
            currentInventory = inventory;
        }
        private void frmTransaction_Load(object sender, EventArgs e)
        {
            lblCarInfo.Text = detailedCarInfo;
        }
        private void btnConfirmCarRental_Click(object sender, EventArgs e)
        {
            if (currentCustomer == null || currentCustomer.CustomerID == 0)
            {
                MessageBox.Show("Please add a customer first.");
                return;
            }
            try
            {
                if (!int.TryParse(txtDays.Text, out int daysRented))
                {
                    MessageBox.Show("Please enter a valid number of days.");
                    return;
                }
                decimal subtotal = Transactions.CalculateTotalCost(currentCar, daysRented);
                decimal carTax = Transactions.CalculateTax(currentCar, daysRented);
                decimal beforeTax = subtotal - carTax;
                DateTime rentalDate = DateTime.Now;
                Transactions transaction = new Transactions
                (
                    rentalDate, currentCustomer, currentCar, daysRented
                );
                bool transactionSuccessful = currentInventory.AddTransaction(currentCar.CarID, currentCustomer.CustomerID, rentalDate, currentCar.RentalCostPerDay, daysRented, subtotal, carTax, false);

                if (transactionSuccessful)
                {
                    currentCar.IsAvailable = false;
                    currentInventory.UpdateCar(currentCar.CarID, currentCar);
                     
                    string dateTimeString = $"{rentalDate:MMMM dd, yyyy}\n{rentalDate:hh:mm tt}";
                    lblReceipt.Text = $"Subtotal before Tax: {beforeTax:C}\n" +
                                      $"Tax Amount: {carTax:C}\n" +
                                      $"Total (with Tax): {subtotal:C}\n" +
                                      $"Date: {dateTimeString}\n";

                    MessageBox.Show("The car has successfully been rented out! Thank you for doing business with us.");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Failed to process the transaction. Please try again.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }
        private bool ValidateFields()
        {
            return !string.IsNullOrWhiteSpace(txtName.Text) &&
                   !string.IsNullOrWhiteSpace(txtPhoneNumber.Text) &&
                   !string.IsNullOrWhiteSpace(txtAddress.Text) &&
                   !string.IsNullOrWhiteSpace(txtLicenseNumber.Text) &&
                   !string.IsNullOrWhiteSpace(txtLicenseState.Text) &&
                   !string.IsNullOrWhiteSpace(txtPolicyNumber.Text) &&
                   !string.IsNullOrWhiteSpace(txtPolicyHolder.Text);
        }
        private void btnAddCustomer_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidateFields())
                {
                    MessageBox.Show("Please fill in all required customer information.");
                    return;
                }
                Customer currentCustomer = new Customer
                (
                    txtName.Text,
                    txtPhoneNumber.Text,
                    txtAddress.Text,
                    txtLicenseNumber.Text,
                    txtLicenseState.Text,
                    txtPolicyNumber.Text,
                    txtPolicyHolder.Text
                );
                DatabaseOperations databaseOperations = new DatabaseOperations();
                currentCustomer.CustomerID = databaseOperations.AddCustomer(currentCustomer);
                if (currentCustomer.CustomerID == 0)
                {
                    MessageBox.Show("Failed to create customer. Please try again.");
                }
                else
                {
                    MessageBox.Show("Customer added successfully!");
                    this.currentCustomer = currentCustomer;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while adding the customer: {ex.Message}");
            }
        }
    }
}

