﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace CarRental
{
    namespace CarRental
    {
        public class Customer
        {
            private int customerID;
            private string name;
            private string phoneNumber;
            private string address;
            private string driverLicenseNumber;
            private string driverLicenseState;
            private string insurancePolicyNumber;
            private string insurancePolicyHolder;
            public int CustomerID { get { return customerID; } set { customerID = value; } }
            public string Name { get { return name; } set { name = value; } }
            public string PhoneNumber { get { return phoneNumber; } set { phoneNumber = value; } }
            public string Address { get { return address; } set { address = value; } }  
            public string DriverLicenseNumber { get { return driverLicenseNumber; } set { driverLicenseNumber = value; } } 
            public string DriverLicenseState { get { return driverLicenseState; } set { driverLicenseState = value; } } 
            public string InsurancePolicyNumber { get { return insurancePolicyNumber; } set { insurancePolicyNumber = value; } }
            public string InsurancePolicyHolder { get { return insurancePolicyHolder; } set { insurancePolicyHolder = value; } }
            
            public Customer (string name, string phoneNumber, string address,
                            string driverLicenseNumber, string driverLicenseState,
                            string insurancePolicyNumber, string insurancePolicyHolder)
            {
                Name = name;
                PhoneNumber = phoneNumber;
                Address = address;
                DriverLicenseNumber = driverLicenseNumber;
                DriverLicenseState = driverLicenseState;
                InsurancePolicyNumber = insurancePolicyNumber;
                InsurancePolicyHolder = insurancePolicyHolder;
            }
        }
    }
}
