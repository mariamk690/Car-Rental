﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRental
{
    public class Car
    {
        private int carID;
        private string category;
        private string manufacturer;
        private string model;
        private int year;
        private double mileage;
        private decimal rentalCostPerDay;
        private bool isAvailable;
        private string description;
        private string parkingSpot;
        private string imageURL;
        private string damages;

        public int CarID { get { return carID; } private set { carID = value; } }
        public string Category { get { return category; } set { category = value; } }
        public string Manufacturer { get { return manufacturer; } set { manufacturer = value; } }
        public string Model { get { return model; } set { model = value; } }
        public int Year { get { return year; } set { year = value; } }
        public double Mileage { get { return mileage; } set { mileage = value; } }
        public decimal RentalCostPerDay { get { return rentalCostPerDay; } set { rentalCostPerDay = value; } }
        public bool IsAvailable { get { return isAvailable; } set { isAvailable = value; } }
        public string Description { get { return description; } set { description = value; } }
        public string ParkingSpot { get { return parkingSpot; } set { parkingSpot = value; } }
        public string ImageURL { get { return imageURL; } set { imageURL = value; } }
        public string Damages { get { return damages; } set { damages = value; } }
        public Car(string category, string manufacturer, string model, int year, double mileage,
            decimal rentalCostPerDay, bool isAvailable, string description, string parkingSpot, string imageURL, string damages)
        {
            Category = category;
            Manufacturer = manufacturer;
            Model = model;
            Year = year;
            Mileage = mileage;
            RentalCostPerDay = rentalCostPerDay;
            IsAvailable = isAvailable;
            Description = description;
            ParkingSpot = parkingSpot;
            ImageURL = imageURL;
            Damages = damages;
        }
        public Car(int carID, string category, string manufacturer, string model, int year, double mileage,
                    decimal rentalCostPerDay, bool isAvailable, string description, string parkingSpot, string imageURL, string damages)
        {
            CarID = carID;
            Category = category;
            Manufacturer = manufacturer;
            Model = model;
            Year = year;
            Mileage = mileage;
            RentalCostPerDay = rentalCostPerDay;
            IsAvailable = isAvailable;
            Description = description;
            ParkingSpot = parkingSpot;
            ImageURL = imageURL;
            Damages = damages;
        }
    }
}
