﻿namespace CarRental
{
    partial class frmDeleteCar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvDeleteCarView = new System.Windows.Forms.DataGridView();
            this.btnDeleteCar = new System.Windows.Forms.Button();
            this.gbSearchFilters = new System.Windows.Forms.GroupBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.chkAvailableFilter = new System.Windows.Forms.CheckBox();
            this.cbCategoryFilter = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDeleteCarView)).BeginInit();
            this.gbSearchFilters.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvDeleteCarView
            // 
            this.dgvDeleteCarView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDeleteCarView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvDeleteCarView.Location = new System.Drawing.Point(32, 38);
            this.dgvDeleteCarView.MultiSelect = false;
            this.dgvDeleteCarView.Name = "dgvDeleteCarView";
            this.dgvDeleteCarView.RowHeadersWidth = 51;
            this.dgvDeleteCarView.RowTemplate.Height = 24;
            this.dgvDeleteCarView.Size = new System.Drawing.Size(970, 317);
            this.dgvDeleteCarView.TabIndex = 8;
            // 
            // btnDeleteCar
            // 
            this.btnDeleteCar.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteCar.Location = new System.Drawing.Point(391, 360);
            this.btnDeleteCar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDeleteCar.Name = "btnDeleteCar";
            this.btnDeleteCar.Size = new System.Drawing.Size(291, 60);
            this.btnDeleteCar.TabIndex = 9;
            this.btnDeleteCar.Text = "Confirm Car Deletion";
            this.btnDeleteCar.UseVisualStyleBackColor = true;
            this.btnDeleteCar.Click += new System.EventHandler(this.btnDeleteCar_Click);
            // 
            // gbSearchFilters
            // 
            this.gbSearchFilters.Controls.Add(this.btnSearch);
            this.gbSearchFilters.Controls.Add(this.chkAvailableFilter);
            this.gbSearchFilters.Controls.Add(this.cbCategoryFilter);
            this.gbSearchFilters.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSearchFilters.Location = new System.Drawing.Point(1008, 38);
            this.gbSearchFilters.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbSearchFilters.Name = "gbSearchFilters";
            this.gbSearchFilters.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbSearchFilters.Size = new System.Drawing.Size(139, 148);
            this.gbSearchFilters.TabIndex = 12;
            this.gbSearchFilters.TabStop = false;
            this.gbSearchFilters.Text = "Search Filters";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(25, 104);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(87, 30);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // chkAvailableFilter
            // 
            this.chkAvailableFilter.AutoSize = true;
            this.chkAvailableFilter.Location = new System.Drawing.Point(19, 77);
            this.chkAvailableFilter.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chkAvailableFilter.Name = "chkAvailableFilter";
            this.chkAvailableFilter.Size = new System.Drawing.Size(100, 23);
            this.chkAvailableFilter.TabIndex = 1;
            this.chkAvailableFilter.Text = "Available?";
            this.chkAvailableFilter.UseVisualStyleBackColor = true;
            // 
            // cbCategoryFilter
            // 
            this.cbCategoryFilter.Font = new System.Drawing.Font("Microsoft YaHei Light", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbCategoryFilter.FormattingEnabled = true;
            this.cbCategoryFilter.Items.AddRange(new object[] {
            "Economy",
            "Luxury",
            "Sedan",
            "SUV",
            "Pickup Truck",
            "Limo",
            "Van"});
            this.cbCategoryFilter.Location = new System.Drawing.Point(19, 33);
            this.cbCategoryFilter.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbCategoryFilter.Name = "cbCategoryFilter";
            this.cbCategoryFilter.Size = new System.Drawing.Size(93, 27);
            this.cbCategoryFilter.TabIndex = 0;
            this.cbCategoryFilter.Text = "Category";
            // 
            // frmDeleteCar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1187, 450);
            this.Controls.Add(this.gbSearchFilters);
            this.Controls.Add(this.btnDeleteCar);
            this.Controls.Add(this.dgvDeleteCarView);
            this.Name = "frmDeleteCar";
            this.Text = "Delete Car";
            this.Load += new System.EventHandler(this.frmDeleteCar_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDeleteCarView)).EndInit();
            this.gbSearchFilters.ResumeLayout(false);
            this.gbSearchFilters.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvDeleteCarView;
        private System.Windows.Forms.Button btnDeleteCar;
        private System.Windows.Forms.GroupBox gbSearchFilters;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.CheckBox chkAvailableFilter;
        private System.Windows.Forms.ComboBox cbCategoryFilter;
    }
}