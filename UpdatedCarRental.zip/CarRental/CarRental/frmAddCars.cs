﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRental
{
    public partial class frmAddCars : Form
    {
        private CarInventory currentInventory;
        public frmAddCars()
        {
            InitializeComponent();
            currentInventory = new CarInventory(); 
        }
        private void btnStoreCar_Click(object sender, EventArgs e)
        {
            try
            {
                Car currentCar = new Car
                (
                    cbCategory.SelectedItem.ToString(),
                    txtManufacturer.Text,
                    txtModel.Text,
                    int.Parse(txtYear.Text),
                    int.Parse(txtMileage.Text),
                    decimal.Parse(txtRentCostPerDay.Text),
                    chkIsAvailable.Checked,
                    txtDescription.Text,
                    txtParkingSpot.Text,
                    txtImageURL.Text,
                    txtDamages.Text
                );
                bool isCarAdded = currentInventory.AddCar(currentCar);
                if (isCarAdded)
                {
                    MessageBox.Show("Car successfully added to the database.");
                }
                else
                {
                    MessageBox.Show("Failed to add car to the database.");
                }
                string imageUrl = txtImageURL.Text;
                if (!string.IsNullOrEmpty(imageUrl))
                {
                    pbCarImage.Load(imageUrl);
                }
                else
                {
                    MessageBox.Show("Please enter a valid image URL.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding car: {ex.Message}");
            }
        }
        private void btnSwitchToRentForm_Click(object sender, EventArgs e)
        {
            frmRentCarView frmRentCarView = new frmRentCarView(currentInventory);
            frmRentCarView.ShowDialog();
        }
        private void btnClearForm_Click(object sender, EventArgs e)
        {
            txtManufacturer.Text = "Manufacturer";
            txtModel.Text = "Model";
            txtYear.Text = "Year";
            txtMileage.Text = "Mileage";
            txtRentCostPerDay.Text = "Rental Cost per Day";
            txtDescription.Text = "Description";
            txtParkingSpot.Text = "Parking Spot";
            txtImageURL.Text = "Image URL";
            pbCarImage.Image = null;
        }
        private void frmAddCars_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Ensure you do not add any commas in any fields. When looking for images, we recommend using pictures from IIHS, as they load the quickest. Thank you!");
        }
        private void btnSwitchToDeleteForm_Click(object sender, EventArgs e)
        {
            frmDeleteCar frmDeleteCar = new frmDeleteCar();
            frmDeleteCar.ShowDialog();
        }
        private void btnSwitchToUpdateForm_Click(object sender, EventArgs e)
        {
            frmUpdateCar frmUpdateCar = new frmUpdateCar();
            frmUpdateCar.ShowDialog();
        }
    }
}