﻿namespace CarRental
{
    partial class frmReturnCar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblReturnInstruct = new System.Windows.Forms.Label();
            this.cbRentedCars = new System.Windows.Forms.ComboBox();
            this.lblNewMileage = new System.Windows.Forms.Label();
            this.txtNewMileage = new System.Windows.Forms.TextBox();
            this.lblDamages = new System.Windows.Forms.Label();
            this.txtDamage = new System.Windows.Forms.TextBox();
            this.btnConfirmReturn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblReturnInstruct
            // 
            this.lblReturnInstruct.AutoSize = true;
            this.lblReturnInstruct.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturnInstruct.Location = new System.Drawing.Point(29, 9);
            this.lblReturnInstruct.Name = "lblReturnInstruct";
            this.lblReturnInstruct.Size = new System.Drawing.Size(415, 19);
            this.lblReturnInstruct.TabIndex = 0;
            this.lblReturnInstruct.Text = "Select the vehicle that is rented that you would like to return:";
            // 
            // cbRentedCars
            // 
            this.cbRentedCars.FormattingEnabled = true;
            this.cbRentedCars.Location = new System.Drawing.Point(92, 36);
            this.cbRentedCars.Name = "cbRentedCars";
            this.cbRentedCars.Size = new System.Drawing.Size(285, 24);
            this.cbRentedCars.TabIndex = 1;
            // 
            // lblNewMileage
            // 
            this.lblNewMileage.AutoSize = true;
            this.lblNewMileage.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewMileage.Location = new System.Drawing.Point(136, 63);
            this.lblNewMileage.Name = "lblNewMileage";
            this.lblNewMileage.Size = new System.Drawing.Size(192, 19);
            this.lblNewMileage.TabIndex = 2;
            this.lblNewMileage.Text = "Input the Updated Mileage:";
            // 
            // txtNewMileage
            // 
            this.txtNewMileage.Location = new System.Drawing.Point(175, 85);
            this.txtNewMileage.Name = "txtNewMileage";
            this.txtNewMileage.Size = new System.Drawing.Size(100, 22);
            this.txtNewMileage.TabIndex = 3;
            // 
            // lblDamages
            // 
            this.lblDamages.AutoSize = true;
            this.lblDamages.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDamages.Location = new System.Drawing.Point(102, 110);
            this.lblDamages.Name = "lblDamages";
            this.lblDamages.Size = new System.Drawing.Size(245, 19);
            this.lblDamages.TabIndex = 4;
            this.lblDamages.Text = "Report any damages to the vehicle:";
            // 
            // txtDamage
            // 
            this.txtDamage.Location = new System.Drawing.Point(115, 132);
            this.txtDamage.Multiline = true;
            this.txtDamage.Name = "txtDamage";
            this.txtDamage.Size = new System.Drawing.Size(232, 64);
            this.txtDamage.TabIndex = 5;
            // 
            // btnConfirmReturn
            // 
            this.btnConfirmReturn.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirmReturn.Location = new System.Drawing.Point(92, 202);
            this.btnConfirmReturn.Name = "btnConfirmReturn";
            this.btnConfirmReturn.Size = new System.Drawing.Size(284, 81);
            this.btnConfirmReturn.TabIndex = 6;
            this.btnConfirmReturn.Text = "Confirm Car Return";
            this.btnConfirmReturn.UseVisualStyleBackColor = true;
            this.btnConfirmReturn.Click += new System.EventHandler(this.btnConfirmReturn_Click);
            // 
            // frmReturnCar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(480, 301);
            this.Controls.Add(this.btnConfirmReturn);
            this.Controls.Add(this.txtDamage);
            this.Controls.Add(this.lblDamages);
            this.Controls.Add(this.txtNewMileage);
            this.Controls.Add(this.lblNewMileage);
            this.Controls.Add(this.cbRentedCars);
            this.Controls.Add(this.lblReturnInstruct);
            this.Name = "frmReturnCar";
            this.Text = "Return Car";
            this.Load += new System.EventHandler(this.frmReturnCar_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblReturnInstruct;
        private System.Windows.Forms.ComboBox cbRentedCars;
        private System.Windows.Forms.Label lblNewMileage;
        private System.Windows.Forms.TextBox txtNewMileage;
        private System.Windows.Forms.Label lblDamages;
        private System.Windows.Forms.TextBox txtDamage;
        private System.Windows.Forms.Button btnConfirmReturn;
    }
}