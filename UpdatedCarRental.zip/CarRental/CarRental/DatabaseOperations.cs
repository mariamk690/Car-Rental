﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Data;
using System.Windows.Forms;
using CarRental.CarRental;

namespace CarRental
{
    public class DatabaseOperations
    {
        private readonly string connectionString;
        public DatabaseOperations()
        {
            connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\RevisedCarInventory.accdb;";
        }
        private OleDbConnection GetConnection()
        {
            return new OleDbConnection(connectionString);
        }

        public bool AddCar(string category, string manufacturer, string model, int year, double mileage, decimal rentalCostPerDay, bool isAvailable, string description, string parkingSpot, string imageURL, string damages)
        {
            using (OleDbConnection connection = GetConnection())
            {
                string query = "INSERT INTO CarInventory (Category, Manufacturer, Model, CarYear, Mileage, RentCostPerDay, Available, Description, ParkingSpot, ImageURL, Damages) " +
                               "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                using (OleDbCommand command = new OleDbCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Category", category);
                    command.Parameters.AddWithValue("@Manufacturer", manufacturer);
                    command.Parameters.AddWithValue("@Model", model);
                    command.Parameters.AddWithValue("@CarYear", year);
                    command.Parameters.AddWithValue("@Mileage", mileage);
                    command.Parameters.AddWithValue("@RentCostPerDay", rentalCostPerDay);
                    command.Parameters.AddWithValue("@Available", isAvailable);
                    command.Parameters.AddWithValue("@Description", description);
                    command.Parameters.AddWithValue("@ParkingSpot", parkingSpot);
                    command.Parameters.AddWithValue("@ImageURL", imageURL);
                    command.Parameters.AddWithValue("@Damages", damages);

                    connection.Open();
                    return command.ExecuteNonQuery() > 0;
                }
            }
        }
        public bool DeleteCar(int carId)
        {
            using (OleDbConnection connection = GetConnection())
            {
                string query = "DELETE FROM CarInventory WHERE CarID = ?";
                using (OleDbCommand command = new OleDbCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CarID", carId);

                    connection.Open();
                    return command.ExecuteNonQuery() > 0;
                }
            }
        }
        public bool UpdateCar(int carId, string category, string manufacturer, string model, int year, double mileage, decimal rentalCostPerDay, bool isAvailable, string description, string parkingSpot, string imageURL, string damages)
        {
            using (OleDbConnection connection = GetConnection())
            {
                string query = "UPDATE CarInventory SET Category = ?, Manufacturer = ?, Model = ?, CarYear = ?, Mileage = ?, RentCostPerDay = ?, Available = ?, Description = ?, ParkingSpot = ?, ImageURL = ?, Damages = ? " +
                               "WHERE CarID = ?";
                using (OleDbCommand command = new OleDbCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Category", category);
                    command.Parameters.AddWithValue("@Manufacturer", manufacturer);
                    command.Parameters.AddWithValue("@Model", model);
                    command.Parameters.AddWithValue("@CarYear", year);
                    command.Parameters.AddWithValue("@Mileage", mileage);
                    command.Parameters.AddWithValue("@RentCostPerDay", rentalCostPerDay);
                    command.Parameters.AddWithValue("@Available", isAvailable);
                    command.Parameters.AddWithValue("@Description", description);
                    command.Parameters.AddWithValue("@ParkingSpot", parkingSpot);
                    command.Parameters.AddWithValue("@ImageURL", imageURL);
                    command.Parameters.AddWithValue("@Damages", damages);
                    command.Parameters.AddWithValue("@CarID", carId);

                    connection.Open();
                    return command.ExecuteNonQuery() > 0;
                }
            }
        }


        public bool AddTransaction(int carId, int customerId, DateTime rentalDate, int daysRented, decimal totalCost, decimal tax, bool carAvailability)
        {
            using (OleDbConnection connection = GetConnection())
            {
                string transactionQuery = "INSERT INTO [Transaction] (CarID, CustomerID, RentalDate, DaysRented, TotalCost, Tax) " +
                                          "VALUES (?, ?, ?, ?, ?, ?)";
                string carUpdateQuery = "UPDATE CarInventory SET Available = ? WHERE CarID = ?";

                using (OleDbCommand transactionCommand = new OleDbCommand(transactionQuery, connection))
                using (OleDbCommand carUpdateCommand = new OleDbCommand(carUpdateQuery, connection))
                {
                    transactionCommand.Parameters.Add("@CarID", OleDbType.Integer).Value = carId;
                    transactionCommand.Parameters.Add("@CustomerID", OleDbType.Integer).Value = customerId;
                    transactionCommand.Parameters.Add("@RentalDate", OleDbType.Date).Value = rentalDate;
                    transactionCommand.Parameters.Add("@DaysRented", OleDbType.Integer).Value = daysRented;
                    transactionCommand.Parameters.Add("@TotalCost", OleDbType.Currency).Value = (double)totalCost;
                    transactionCommand.Parameters.Add("@Tax", OleDbType.Currency).Value = (double)tax;

                    carUpdateCommand.Parameters.Add("@Available", OleDbType.Boolean).Value = carAvailability ? -1 : 0;
                    carUpdateCommand.Parameters.Add("@CarID", OleDbType.Integer).Value = carId;

                    connection.Open();
                    var transactionResult = transactionCommand.ExecuteNonQuery() > 0;
                    var carUpdateResult = carUpdateCommand.ExecuteNonQuery() > 0;

                    return transactionResult && carUpdateResult;
                }
            }
        }
        public DataTable SearchCars(string category, bool? isAvailable)
        {
            using (OleDbConnection connection = GetConnection())
            {
                string query = "SELECT * FROM CarInventory WHERE 1=1";
                if (!string.IsNullOrEmpty(category))
                {
                    query += " AND Category = ?";
                }
                if (isAvailable.HasValue)
                {
                    query += " AND Available = ?";
                }

                using (OleDbCommand command = new OleDbCommand(query, connection))
                {
                    if (!string.IsNullOrEmpty(category))
                    {
                        command.Parameters.AddWithValue("@Category", category);
                    }
                    if (isAvailable.HasValue)
                    {
                        command.Parameters.AddWithValue("@Available", isAvailable.Value);
                    }

                    connection.Open();
                    OleDbDataAdapter adapter = new OleDbDataAdapter(command);
                    DataTable searchResults = new DataTable();
                    adapter.Fill(searchResults);
                    return searchResults;
                }
            }
        }

        public DataTable GetAllCars()
        {
            using (OleDbConnection connection = GetConnection())
            {
                string query = "SELECT CarID, Category, Manufacturer, Model, CarYear, Mileage, Description, ParkingSpot, RentCostPerDay, Available, ImageURL, Damages FROM CarInventory";
                using (OleDbCommand command = new OleDbCommand(query, connection))
                {
                    connection.Open();
                    OleDbDataAdapter adapter = new OleDbDataAdapter(command);
                    DataTable carsTable = new DataTable();
                    adapter.Fill(carsTable);
                    return carsTable;
                }
            }
        }
        public int AddCustomer(Customer customer)
        {
            int newCustomerId = 0;

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                string query = "INSERT INTO Customer (FullName, PhoneNumber, Address, DLNumber, DLState, InsurancePolicyNumber, InsurancePolicyHolder) " +
                               "VALUES (@Name, @PhoneNumber, @Address, @LicenseNumber, @LicenseState, @PolicyNumber, @PolicyHolder)";
                OleDbCommand command = new OleDbCommand(query, connection);
                command.Parameters.AddWithValue("@FullName", customer.Name);
                command.Parameters.AddWithValue("@PhoneNumber", customer.PhoneNumber);
                command.Parameters.AddWithValue("@Address", customer.Address);
                command.Parameters.AddWithValue("@DLNumber", customer.DriverLicenseNumber);
                command.Parameters.AddWithValue("@DLState", customer.DriverLicenseState);
                command.Parameters.AddWithValue("@InsurancePolicyNumber", customer.InsurancePolicyNumber);
                command.Parameters.AddWithValue("@InsurancePolicyHolder", customer.InsurancePolicyHolder);


                connection.Open();
                command.ExecuteNonQuery();

                command.CommandText = "SELECT @@IDENTITY";
                newCustomerId = Convert.ToInt32(command.ExecuteScalar());
            }

            return newCustomerId;
        }


    }

}
