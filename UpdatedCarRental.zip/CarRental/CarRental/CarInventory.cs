﻿using System;
using System.Collections.Generic;
using System.Data;

namespace CarRental
{
    public class CarInventory
    {
        private DatabaseOperations dbOperations;

        public CarInventory()
        {
            dbOperations = new DatabaseOperations();
        }
        public bool AddCar(Car car)
        {
            return dbOperations.AddCar(car.Category, car.Manufacturer, car.Model, car.Year, car.Mileage, car.RentalCostPerDay, car.IsAvailable, car.Description, car.ParkingSpot, car.ImageURL, car.Damages);
        }

        public bool AddTransaction(int carId, int customerId, DateTime rentalDate, decimal rentalCostPerDay, int daysRented, decimal totalCost, decimal tax, bool carAvailability)
        {
            return dbOperations.AddTransaction(carId, customerId, rentalDate, daysRented, totalCost, tax, carAvailability);
        }
        public List<Car> GetCars()
        {
            DataTable carsTable = dbOperations.GetAllCars();
            List<Car> cars = new List<Car>();

            foreach (DataRow row in carsTable.Rows)
            {
                Car car = new Car
                (
                    int.Parse(row["CarID"].ToString()),
                    row["Category"].ToString(),
                    row["Manufacturer"].ToString(),
                    row["Model"].ToString(),
                    int.Parse(row["CarYear"].ToString()),
                    int.Parse(row["Mileage"].ToString()),
                    decimal.Parse(row["RentCostPerDay"].ToString()),
                    bool.Parse(row["Available"].ToString()),
                    row["Description"].ToString(),
                    row["ParkingSpot"].ToString(),
                    row["ImageURL"].ToString(),
                    row["Damages"].ToString()
                );
                cars.Add(car);
            }
            return cars;
        }
        public bool UpdateCar(int carId, Car updatedCar)
        {
            return dbOperations.UpdateCar(carId, updatedCar.Category, updatedCar.Manufacturer, updatedCar.Model, updatedCar.Year, updatedCar.Mileage, updatedCar.RentalCostPerDay, updatedCar.IsAvailable, updatedCar.Description, updatedCar.ParkingSpot, updatedCar.ImageURL, updatedCar.Damages);
        }
    }
}
