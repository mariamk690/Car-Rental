﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRental
{
    public partial class frmUpdateCar : Form
    {
        private DatabaseOperations dbOperations = new DatabaseOperations();
        private BindingSource carBindingSource = new BindingSource();
        public frmUpdateCar()
        {
            InitializeComponent();
        }
        private void frmUpdateCar_Load(object sender, EventArgs e)
        {
            LoadCarData();
            dgvEditCarView.Columns["CarID"].ReadOnly = true;
            dgvEditCarView.Columns["ImageURL"].ReadOnly = true;
            dgvEditCarView.Columns["Category"].ReadOnly = true;
        }
        private void LoadCarData()
        {
            DataTable carsTable = dbOperations.GetAllCars();
            carBindingSource.DataSource = carsTable;
            dgvEditCarView.DataSource = carBindingSource;
        }
        private void btnSaveChanges_Click(object sender, EventArgs e)
        {
            DatabaseOperations dbOperations = new DatabaseOperations();

            foreach (DataGridViewRow row in dgvEditCarView.Rows)
            {
                if (row.IsNewRow) continue; 

                int carId = (int)row.Cells["CarID"].Value;
                string category = row.Cells["Category"].Value.ToString();
                string manufacturer = row.Cells["Manufacturer"].Value.ToString();
                string model = row.Cells["Model"].Value.ToString();
                int year = Convert.ToInt32(row.Cells["CarYear"].Value);
                double mileage = Convert.ToDouble(row.Cells["Mileage"].Value);
                decimal rentalCostPerDay = Convert.ToDecimal(row.Cells["RentCostPerDay"].Value);
                bool isAvailable = Convert.ToBoolean(row.Cells["Available"].Value);
                string description = row.Cells["Description"].Value.ToString();
                string parkingSpot = row.Cells["ParkingSpot"].Value.ToString();
                string imageURL = row.Cells["ImageURL"].Value.ToString();
                string damages = row.Cells["Damages"].Value.ToString();

                bool success = dbOperations.UpdateCar(carId, category, manufacturer, model, year, mileage, rentalCostPerDay, isAvailable, description, parkingSpot, imageURL, damages);

                if (!success)
                {
                    MessageBox.Show($"Failed to update car with ID {carId}.");
                }
            }
            MessageBox.Show("Successfully updated the data."); 
            LoadCarData();
        }
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string selectedCategory = cbCategoryFilter.SelectedItem?.ToString();
            bool? isAvailable = chkAvailableFilter.Checked;
            DataTable searchResults = dbOperations.SearchCars(selectedCategory, isAvailable);
            carBindingSource.DataSource = searchResults;

        }
    }
}
