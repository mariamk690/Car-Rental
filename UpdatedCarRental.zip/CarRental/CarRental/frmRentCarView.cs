﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarRental
{
    public partial class frmRentCarView : Form
    {
        private DatabaseOperations dbOperations;
        private BindingSource carBindingSource;
        private CarInventory currentInventory;
        public frmRentCarView(CarInventory inventory)
        {
            currentInventory = inventory;
            InitializeComponent();
            dbOperations = new DatabaseOperations();
            carBindingSource = new BindingSource(); 
            InitializeDataGridView();
            LoadCars();
        }
        private void InitializeDataGridView()
        {
            dgvCarView.AutoGenerateColumns = false;
            dgvCarView.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Category" });
            dgvCarView.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Manufacturer" });
            dgvCarView.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Model" });
            dgvCarView.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "RentCostPerDay" });
            dgvCarView.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Available" });

            dgvCarView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvCarView.DataSource = carBindingSource;
        }
        private void LoadCars()
        {
            DataTable carsTable = dbOperations.GetAllCars();
            carBindingSource.DataSource = carsTable; 
        }
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string selectedCategory = cbCategoryFilter.SelectedItem?.ToString();
            bool isAvailable = chkAvailableFilter.Checked;
            DataTable searchResults = dbOperations.SearchCars(selectedCategory, isAvailable);
            carBindingSource.DataSource = searchResults;
        }
        private void dgvCarView_SelectionChanged(object sender, EventArgs e)
        {
            if (carBindingSource.Current is DataRowView selectedRow)
            {
                if (!string.IsNullOrEmpty(selectedRow["Category"].ToString()))
                {
                    Car selectedCar = new Car
                    (
                        selectedRow["Category"].ToString(),
                        selectedRow["Manufacturer"].ToString(),
                        selectedRow["Model"].ToString(),
                        int.Parse(selectedRow["CarYear"].ToString()),
                        double.Parse(selectedRow["Mileage"].ToString()),
                        decimal.Parse(selectedRow["RentCostPerDay"].ToString()),
                        bool.Parse(selectedRow["Available"].ToString()),
                        selectedRow["Description"].ToString(),
                        selectedRow["ParkingSpot"].ToString(),
                        selectedRow["ImageURL"].ToString(),
                        selectedRow["Damages"].ToString()
                    );

                    DisplayCarDetails(selectedCar);
                }
            }
        }
        private void DisplayCarDetails(Car car)
        {
            lblDetailedCarInfo.Text = $"Category: {car.Category} | " +
                                      $"Manufacturer: {car.Manufacturer} | " +
                                      $"Model: {car.Model} | " +
                                      $"Year: {car.Year} | " +
                                      $"Mileage: {car.Mileage} miles\n" +
                                      $"Rental Cost Per Day: {car.RentalCostPerDay:C}\n" +
                                      $"Availability: {(car.IsAvailable ? "Available" : "Rented")}\n" +
                                      $"Description: {car.Description}\n" +
                                      $"Parking Spot: {car.ParkingSpot}\n" +
                                      $"Damages: {car.Damages}\n";
            if (!string.IsNullOrEmpty(car.ImageURL))
            {
                pbDetailedCarView.Load(car.ImageURL);
            }
            else
            {
                pbDetailedCarView.Image = null;
            }
        }
        private void btnConfirmCar_Click(object sender, EventArgs e)
        {
            if (carBindingSource.Current is DataRowView selectedRow)
            {
                int carId = int.Parse(selectedRow["CarID"].ToString());
                bool carAvailability = (bool)selectedRow["Available"];

                if (!carAvailability)
                {
                    MessageBox.Show("This car is currently rented.");
                    return;
                }

                Car selectedCar = new Car
                (
                    int.Parse(selectedRow["CarID"].ToString()),
                    selectedRow["Category"].ToString(),
                    selectedRow["Manufacturer"].ToString(),
                    selectedRow["Model"].ToString(),
                    int.Parse(selectedRow["CarYear"].ToString()),
                    double.Parse(selectedRow["Mileage"].ToString()),
                    decimal.Parse(selectedRow["RentCostPerDay"].ToString()),
                    (bool)selectedRow["Available"],
                    selectedRow["Description"].ToString(),
                    selectedRow["ParkingSpot"].ToString(),
                    selectedRow["ImageURL"].ToString(),
                    selectedRow["Damages"].ToString()
                );

                string detailedCarInfo = $"Category: {selectedCar.Category}\n" +
                                         $"Manufacturer: {selectedCar.Manufacturer}\n" +
                                         $"Model: {selectedCar.Model}\n" +
                                         $"Rental Cost Per Day: {selectedCar.RentalCostPerDay:C}\n" +
                                         $"Availability: {(selectedCar.IsAvailable ? "Available" : "Rented")}";

                frmTransaction transactionForm = new frmTransaction(selectedCar, detailedCarInfo, currentInventory);
                transactionForm.ShowDialog();
                this.Close();
            }

        }
        private void btnSwitchToReturnForm_Click(object sender, EventArgs e)
        {
            this.Close();
            frmReturnCar frmReturnCar = new frmReturnCar();
            frmReturnCar.ShowDialog();
        }

        private void frmRentCarView_Load(object sender, EventArgs e)
        {
            LoadCars();
        }
    }
}
